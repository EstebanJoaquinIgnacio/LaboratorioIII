﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades
{
    public class Programador
    {
        private ECategoria _categoria;
        private DateTime _horaIngreso;
        private int _legajo;
        private string _nombre;
        private double _pagoPorHoras;

        public ECategoria Categoria
        { get; set; }

        public DateTime HoraIngreso
        { get; set; }

        public int Legajo
        { get; set; }

        public string Nombre
        { get; set; }

        public Double PagoPorHoras
        {
            get ;
            set;
        }

        public Programador(string nombre, int legajo, double pago, DateTime hora)
        {
        }

        public int OrdenarPorCategoria(Programador proUno, Programador proDos)
        {
            return 0;
        }
        public int OrdenarPorHora(Programador proUno, Programador proDos)
        {
            return 0;
        }

        public int OrdenarPorLegajo(Programador proUno, Programador proDos)
        {
            return 0;
        }

        string ToString(){}
        
    }
}
